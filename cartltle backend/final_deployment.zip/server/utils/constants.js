export const MESSAGE_ROUTES = "/messages";

export const GET_ALL_MESSAGES_ROUTES = `${MESSAGE_ROUTES}/get-messages`;
// cloudinaryConfig.js
const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: 'dhch0lsvt',
  api_key: '222935291778585',
  api_secret: '3O1McB8X6ABfVFAEWz-h99r9YWk',
});

module.exports = cloudinary;
